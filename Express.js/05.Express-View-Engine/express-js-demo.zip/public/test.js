function calc () {
  console.log(5 + 5)
}

calc()
