const user = require('./user-controller')
const home = require('./home-controller')
const order = require('./order-controller')

module.exports = {
    user,
    home,
    order
}
