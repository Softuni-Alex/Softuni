﻿namespace AirConditioner.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}