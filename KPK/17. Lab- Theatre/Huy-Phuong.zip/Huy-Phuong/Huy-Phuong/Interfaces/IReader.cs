﻿namespace Huy_Phuong.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
