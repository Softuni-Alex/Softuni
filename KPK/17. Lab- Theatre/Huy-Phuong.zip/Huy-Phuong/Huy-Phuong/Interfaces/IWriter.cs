﻿namespace Huy_Phuong.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string output);
    }
}
