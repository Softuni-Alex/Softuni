﻿namespace Huy_Phuong.Interfaces
{
    using System;
    public interface ITheatre : IComparable
    {
        string Name { get; }
    }
}
