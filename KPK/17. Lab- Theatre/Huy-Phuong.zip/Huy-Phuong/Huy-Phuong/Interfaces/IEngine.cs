﻿namespace Huy_Phuong.Interfaces
{
    interface IEngine : IRunnable
    {
    }
}
