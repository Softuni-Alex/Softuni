﻿namespace Huy_Phuong.Interfaces
{
    public interface IRunnable
    {
        void Run();
    }
}
