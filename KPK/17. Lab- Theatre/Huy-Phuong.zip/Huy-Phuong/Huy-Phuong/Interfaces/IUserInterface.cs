﻿namespace Huy_Phuong.Interfaces
{
    public interface IUserInterface : IReader, IWriter
    {
    }
}
