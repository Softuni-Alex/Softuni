﻿namespace TicketOffice
{
    public enum TicketType
    {
        Bus,
        Flight,
        Train
    }
}
