﻿namespace buls
{
    using Core;

    public class Program
    {
        public static void Main()
        {
            var इंजन = new बंगलौर_विश्वविद्यालय_इंजन();
            इंजन.रन();
        }
    }
}