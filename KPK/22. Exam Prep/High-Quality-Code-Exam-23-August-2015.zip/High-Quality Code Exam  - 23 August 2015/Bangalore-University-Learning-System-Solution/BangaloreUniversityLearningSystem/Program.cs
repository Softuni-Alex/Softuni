﻿namespace BangaloreUniversityLearningSystem
{
    using Core;

    public class Program
    {
        public static void Main()
        {
			var engine = new BangaloreUniversityEngine();
			engine.Run();
        }
    }
} 