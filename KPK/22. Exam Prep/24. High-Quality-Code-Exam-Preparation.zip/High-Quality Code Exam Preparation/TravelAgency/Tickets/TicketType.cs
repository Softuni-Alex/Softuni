﻿namespace TravelAgency.Tickets
{
    public enum TicketType
    {
        Air,
        Bus,
        Train
    }
}
