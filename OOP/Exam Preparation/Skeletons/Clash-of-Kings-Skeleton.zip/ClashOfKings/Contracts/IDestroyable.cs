﻿namespace ClashOfKings.Contracts
{
    public interface IDestroyable
    {
        int Armor { get; }
    }
}
