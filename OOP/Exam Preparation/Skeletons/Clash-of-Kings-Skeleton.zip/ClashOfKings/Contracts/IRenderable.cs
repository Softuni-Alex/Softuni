﻿namespace ClashOfKings.Contracts
{
    public interface IRenderable
    {
        string Print();
    }
}
