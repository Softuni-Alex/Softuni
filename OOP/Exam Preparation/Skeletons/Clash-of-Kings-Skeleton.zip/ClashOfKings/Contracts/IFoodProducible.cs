﻿namespace ClashOfKings.Contracts
{
    public interface IFoodProducible
    {
        double FoodProduction { get; set; }

        double FoodStorage { get; set; }
    }
}
