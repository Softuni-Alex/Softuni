﻿namespace ClashOfKings.Models.Armies
{
    public enum UnitType
    {
        Infantry,
        Cavalry,
        AirForce
    }
}
