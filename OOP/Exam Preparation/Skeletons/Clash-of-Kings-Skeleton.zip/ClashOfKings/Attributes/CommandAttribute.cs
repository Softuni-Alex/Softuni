﻿namespace ClashOfKings.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Class)]
    public class CommandAttribute : Attribute
    {
    }
}
