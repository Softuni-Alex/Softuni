﻿namespace ClashOfKings.Models
{
    public enum CityType
    {
        Keep,
        FortifiedCity,
        Fortress,
        Megapolis,
        Capital
    }
}
