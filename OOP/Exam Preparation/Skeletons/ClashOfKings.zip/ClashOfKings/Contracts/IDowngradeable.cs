﻿namespace ClashOfKings.Contracts
{
    public interface IDowngradeable
    {
        void Downgrade();
    }
}
