﻿namespace ClashOfKings.Contracts
{
    public interface IUpdateable
    {
        void Update();
    }
}
