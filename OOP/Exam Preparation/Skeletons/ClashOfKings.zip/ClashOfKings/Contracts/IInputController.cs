﻿namespace ClashOfKings.Contracts
{
    public interface IInputController
    {
        string ReadInput();
    }
}
