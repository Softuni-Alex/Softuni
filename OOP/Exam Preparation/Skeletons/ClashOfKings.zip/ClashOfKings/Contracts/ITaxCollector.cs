﻿namespace ClashOfKings.Contracts
{
    public interface ITaxCollector
    {
        decimal TreasuryAmount { get; set; }
    }
}
