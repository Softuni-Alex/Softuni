﻿namespace ClashOfKings.Contracts
{
    public interface IAttack
    {
        int Damage { get; }
    }
}
