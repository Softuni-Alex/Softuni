﻿namespace ClashOfKings.Contracts
{
    public interface IDefendable
    {
        int Defense { get; }
    }
}
