﻿namespace ClashOfKings.Contracts
{
    public interface ITaxable
    {
        decimal TaxBase { get; set; }
    }
}
