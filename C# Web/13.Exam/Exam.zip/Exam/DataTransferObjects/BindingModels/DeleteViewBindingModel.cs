﻿namespace DataTransferObjects.BindingModels
{
    public class DeleteViewBindingModel
    {
        public int Id { get; set; }

        public string Title { get; set; }
    }
}
